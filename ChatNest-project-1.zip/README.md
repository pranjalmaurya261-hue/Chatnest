# ChatNest

A mobile-first one-to-one messaging app built with React, TypeScript, Vite, Supabase Auth, PostgreSQL, Supabase Realtime, Lucide React and Framer Motion.

**Important:** This repository contains the application source. Real authentication and messaging work only after you connect a Supabase project and run the SQL setup. No fake users or demo messages are included.

## Requirements

- Node.js 20.19+ (or a current supported Node.js LTS)
- npm
- A free Supabase account/project

## 1. Create a Supabase project

1. Open [Supabase](https://supabase.com/) and sign in.
2. Create a new project and save the database password somewhere safe.
3. Wait for the project to finish provisioning.
4. In **Project Settings → API** (wording may appear as **Connect** / **API Keys** in the dashboard), copy:
   - Project URL
   - The public `anon` key or publishable key (`sb_publishable_...`)
5. Never use the `service_role` / secret key in the frontend.

## 2. Configure the database

1. Open your project’s **SQL Editor**.
2. Open `supabase/schema.sql` from this project.
3. Copy all its contents into a new SQL query and run it.
4. Confirm the `profiles` and `messages` tables exist under **Table Editor**.
5. Under **Database → Publications** (if needed), confirm `messages` is in the `supabase_realtime` publication. The SQL attempts to add it automatically.

The SQL creates profile/message tables, indexes, constraints, row-level security policies, a signup trigger, and the Realtime publication entry. It does not expose email addresses through the public profile table.

### Email confirmation

By default, Supabase may require email confirmation. If enabled, sign-up creates the account but the user may need to click the confirmation email before logging in. For a quick private test, adjust **Authentication → URL Configuration** and email settings in your Supabase dashboard as appropriate. Do not disable confirmation for a public production app without considering abuse risk.

## 3. Set environment variables

At the project root, copy `.env.example` to a new file named `.env`:

```bash
cp .env.example .env
```

On Windows, make a copy of `.env.example` and name it `.env`.

Fill it in:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_OR_PUBLISHABLE_KEY
```

Do not commit `.env`. The `VITE_` values are included in the browser bundle, so only the public anon/publishable key is appropriate. Never put a service-role key in a `VITE_` variable.

## 4. Run locally

From the project folder:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite, usually `http://localhost:5173`.

For a production build:

```bash
npm run build
npm run preview
```

## 5. Deploy to Netlify

1. Push the project to a Git repository, or upload the project to your Git provider.
2. In [Netlify](https://www.netlify.com/), choose **Add new site → Import an existing project**.
3. Set build command to `npm run build` and publish directory to `dist` (also configured in `netlify.toml`).
4. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in **Site configuration → Environment variables**.
5. Deploy the site.
6. In Supabase **Authentication → URL Configuration**, set the deployed site as the Site URL and add the deployed URL to allowed redirect URLs if needed.
7. Redeploy after changing environment variables.

For Vercel, import the repository, use the Vite preset, and add the same two environment variables. Configure SPA fallback routing if you add client-side routes later.

## 6. Open on an Android phone

- **Deployed version:** open the Netlify/Vercel URL in Chrome on Android. Optionally use Chrome’s menu → **Add to Home screen**.
- **Same Wi-Fi local test:** run `npm run dev -- --host 0.0.0.0` on your computer and open the network URL Vite prints on your phone. Both devices must be on the same Wi-Fi. Configure the Supabase Auth Site URL/redirect settings for your actual production URL before public deployment.

## Features implemented

- Email/password sign-up and login through Supabase Auth
- Auth session persistence and logout
- Unique username validation in UI and case-insensitive database uniqueness
- Profile display name/username editing
- People directory with username/display-name search; excludes current user and never queries email from profiles
- One-to-one text messages stored in PostgreSQL
- Live inserts through Supabase Realtime
- Message history on conversation open and after refresh
- RLS policies limiting message reads to sender/receiver and sends to the authenticated sender
- Responsive desktop sidebar/chat layout and mobile full-screen chat with back button
- Loading, empty, success/error states, toast notifications, and accessible labels
- No voice/video calling, fake production data, or service-role key

## Security notes and limitations

- RLS protects database access even if a client is modified. Do not disable RLS.
- The profile directory is visible to authenticated users by design; profile rows do not contain email addresses.
- Messages are immutable from the client (no update/delete policies).
- The current message screen loads the latest 1,000 messages for the selected conversation. Pagination/read receipts/typing indicators are intentionally out of scope for this lightweight first version.
- Supabase Realtime delivery depends on the table being in the Realtime publication and RLS/configuration being correct.
- This app is not end-to-end encrypted; database access is protected by Supabase Auth and RLS, but the service/database operators can still access stored messages.
- Username collisions during the signup trigger get a generated suffix to ensure account creation can proceed; the user can edit their username later in Profile & settings.

## Test checklist

The project was source-generated in this environment. A live Supabase project was not available here, so **the following end-to-end checks have not been executed against a real backend**:

- [ ] Create two accounts and confirm the signup/email-confirmation flow
- [ ] Log in and log out
- [ ] Confirm each account can find the other by username/display name
- [ ] Send a message between two separate browser/device sessions and confirm realtime delivery
- [ ] Refresh and confirm message history persists
- [ ] Verify a third account cannot read the first two accounts’ conversation
- [ ] Test desktop and Android viewport sizes

Run these checks after setup before treating the app as production-ready.

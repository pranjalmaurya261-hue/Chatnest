import { FormEvent, useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowLeft, ArrowUpRight, Check, CheckCheck, ChevronDown, CircleUserRound,
  LogOut, MessageCircle, MessageCircleMore, Search, Send, Settings2, ShieldCheck,
  Sparkles, UserRound, Users, X, Leaf, LockKeyhole, Mail, LoaderCircle,
} from 'lucide-react'
import { hasSupabaseConfig, supabase, type Message, type Profile } from './lib/supabase'

type Toast = { id: number; text: string; kind: 'success' | 'error' | 'info' }
type AuthMode = 'login' | 'signup'

const initials = (name: string) => name.trim().split(/\s+/).slice(0, 2).map(s => s[0]).join('').toUpperCase() || '?'
const avatarColor = (name: string) => {
  const palette = ['#d7eee0', '#f3e5c8', '#dbe8f4', '#f1dce5', '#e6e0f6']
  const index = [...name].reduce((n, c) => n + c.charCodeAt(0), 0) % palette.length
  return palette[index]
}
const formatTime = (date: string) => new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' }).format(new Date(date))
const formatDay = (date: string) => {
  const d = new Date(date)
  const today = new Date()
  if (d.toDateString() === today.toDateString()) return 'Today'
  const yesterday = new Date(); yesterday.setDate(today.getDate() - 1)
  if (d.toDateString() === yesterday.toDateString()) return 'Yesterday'
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' }).format(d)
}

function Avatar({ profile, size = 'md' }: { profile: Pick<Profile, 'display_name' | 'username' | 'avatar_url'>; size?: 'sm' | 'md' | 'lg' }) {
  return <span className={`avatar avatar-${size}`} style={{ background: avatarColor(profile.username || profile.display_name) }}>
    {profile.avatar_url ? <img src={profile.avatar_url} alt="" /> : initials(profile.display_name || profile.username)}
  </span>
}

function App() {
  const [session, setSession] = useState<any>(null)
  const [authReady, setAuthReady] = useState(false)
  const [authMode, setAuthMode] = useState<AuthMode>('login')
  const [authBusy, setAuthBusy] = useState(false)
  const [authError, setAuthError] = useState('')
  const [authSuccess, setAuthSuccess] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [displayName, setDisplayName] = useState('')
  const [username, setUsername] = useState('')
  const [people, setPeople] = useState<Profile[]>([])
  const [peopleLoading, setPeopleLoading] = useState(false)
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState<Profile | null>(null)
  const [mobileChatOpen, setMobileChatOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [messagesLoading, setMessagesLoading] = useState(false)
  const [messageText, setMessageText] = useState('')
  const [sending, setSending] = useState(false)
  const [toast, setToast] = useState<Toast | null>(null)
  const [profileOpen, setProfileOpen] = useState(false)
  const [editName, setEditName] = useState('')
  const [editUsername, setEditUsername] = useState('')
  const [profileBusy, setProfileBusy] = useState(false)
  const [profileError, setProfileError] = useState('')
  const [profile, setProfile] = useState<Profile | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const messageInputRef = useRef<HTMLInputElement>(null)
  const toastCounter = useRef(0)

  const notify = useCallback((text: string, kind: Toast['kind'] = 'info') => {
    const id = ++toastCounter.current
    setToast({ id, text, kind })
    window.setTimeout(() => setToast(current => current?.id === id ? null : current), 3600)
  }, [])

  useEffect(() => {
    if (!hasSupabaseConfig) { setAuthReady(true); return }
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session)
      setAuthReady(true)
    }).catch(() => setAuthReady(true))
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession)
    })
    return () => subscription.unsubscribe()
  }, [])

  const loadProfile = useCallback(async () => {
    if (!session?.user?.id) return
    const { data, error } = await supabase.from('profiles').select('*').eq('id', session.user.id).maybeSingle()
    if (error) { notify('Could not load your profile. Check your Supabase setup.', 'error'); return }
    if (data) setProfile(data as Profile)
  }, [session, notify])

  const loadPeople = useCallback(async () => {
    if (!session?.user?.id) return
    setPeopleLoading(true)
    const { data, error } = await supabase.from('profiles').select('id,username,display_name,avatar_url,created_at')
      .neq('id', session.user.id).order('display_name', { ascending: true }).limit(500)
    if (error) notify('Could not load people. Please check your database policies.', 'error')
    else setPeople((data || []) as Profile[])
    setPeopleLoading(false)
  }, [session, notify])

  useEffect(() => {
    if (session?.user?.id) {
      void loadProfile()
      void loadPeople()
    } else {
      setProfile(null); setPeople([]); setSelected(null); setMessages([])
    }
  }, [session?.user?.id, loadProfile, loadPeople])

  const filteredPeople = useMemo(() => {
    const query = search.trim().replace(/^@/, '').toLowerCase()
    if (!query) return people
    return people.filter(p => p.username.toLowerCase().includes(query) || p.display_name.toLowerCase().includes(query))
  }, [people, search])

  const loadMessages = useCallback(async (other: Profile) => {
    if (!session?.user?.id) return
    setMessagesLoading(true)
    const { data, error } = await supabase.from('messages').select('*')
      .or(`and(sender_id.eq.${session.user.id},receiver_id.eq.${other.id}),and(sender_id.eq.${other.id},receiver_id.eq.${session.user.id})`)
      .order('created_at', { ascending: true }).limit(1000)
    if (error) notify('Could not load this conversation.', 'error')
    else setMessages((data || []) as Message[])
    setMessagesLoading(false)
  }, [session, notify])

  useEffect(() => {
    if (selected && session?.user?.id) void loadMessages(selected)
    else setMessages([])
  }, [selected?.id, session?.user?.id, loadMessages])

  useEffect(() => {
    if (!session?.user?.id) return
    const channel = supabase.channel(`chatnest-messages-${session.user.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, payload => {
        const incoming = payload.new as Message
        if (incoming.sender_id !== session.user.id && incoming.receiver_id !== session.user.id) return
        setMessages(current => {
          if (current.some(m => m.id === incoming.id)) return current
          if (selected && !(
            (incoming.sender_id === session.user.id && incoming.receiver_id === selected.id) ||
            (incoming.sender_id === selected.id && incoming.receiver_id === session.user.id)
          )) return current
          return [...current, incoming].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
        })
      }).subscribe()
    return () => { void supabase.removeChannel(channel) }
  }, [session?.user?.id, selected?.id])

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }) }, [messages, mobileChatOpen])

  async function handleAuth(event: FormEvent) {
    event.preventDefault(); setAuthError(''); setAuthSuccess('')
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return setAuthError('Enter a valid email address.')
    if (password.length < 8) return setAuthError('Password must be at least 8 characters.')
    if (authMode === 'signup') {
      if (!/^[a-zA-Z0-9_]{3,24}$/.test(username)) return setAuthError('Username must be 3–24 characters: letters, numbers or underscores.')
      if (displayName.trim().length < 1 || displayName.trim().length > 60) return setAuthError('Display name must be 1–60 characters.')
    }
    setAuthBusy(true)
    try {
      if (authMode === 'signup') {
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(), password,
          options: { data: { username: username.trim(), display_name: displayName.trim() } },
        })
        if (error) throw error
        if (!data.session) setAuthSuccess('Account created. Check your email to confirm it, then log in.')
        else setAuthSuccess('Welcome to ChatNest!')
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password })
        if (error) throw error
      }
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Authentication failed. Please try again.')
    } finally { setAuthBusy(false) }
  }

  async function handleLogout() {
    const { error } = await supabase.auth.signOut()
    if (error) notify(error.message, 'error')
    else { setProfileOpen(false); setMobileChatOpen(false); notify('You have been logged out.', 'success') }
  }

  async function sendMessage(event: FormEvent) {
    event.preventDefault()
    const body = messageText.trim()
    if (!body || !selected || !session?.user?.id || sending) return
    if (body.length > 4000) return notify('Messages can be up to 4,000 characters.', 'error')
    setSending(true)
    setMessageText('')
    const { data, error } = await supabase.from('messages')
      .insert({ sender_id: session.user.id, receiver_id: selected.id, body })
      .select('*').single()
    if (error) {
      setMessageText(body)
      notify(error.message.includes('row-level security') ? 'Message blocked by security policy. Check the SQL setup.' : 'Message could not be sent. Please try again.', 'error')
    } else {
      setMessages(current => current.some(m => m.id === data.id) ? current : [...current, data as Message])
    }
    setSending(false)
    messageInputRef.current?.focus()
  }

  function openPerson(person: Profile) {
    setSelected(person); setMobileChatOpen(true)
  }

  function openProfile() {
    setEditName(profile?.display_name || '')
    setEditUsername(profile?.username || '')
    setProfileError('')
    setProfileOpen(true)
  }

  async function saveProfile(event: FormEvent) {
    event.preventDefault()
    if (!profile) return
    const name = editName.trim()
    const user = editUsername.trim()
    if (name.length < 1 || name.length > 60) return setProfileError('Display name must be 1–60 characters.')
    if (!/^[a-zA-Z0-9_]{3,24}$/.test(user)) return setProfileError('Username must be 3–24 characters: letters, numbers or underscores.')
    setProfileBusy(true); setProfileError('')
    const { data, error } = await supabase.from('profiles').update({ display_name: name, username: user }).eq('id', profile.id).select().single()
    if (error) setProfileError(error.code === '23505' ? 'That username is already taken.' : error.message)
    else {
      setProfile(data as Profile)
      setPeople(current => current.map(p => p.id === data.id ? data as Profile : p))
      setProfileOpen(false); notify('Profile updated.', 'success')
    }
    setProfileBusy(false)
  }

  if (!authReady) return <div className="startup"><div className="brand-mark"><Leaf size={25} /></div><span className="loader-dot" /><p>Getting your nest ready…</p></div>

  if (!hasSupabaseConfig) return <SetupScreen />

  if (!session) return <AuthScreen
    mode={authMode} setMode={mode => { setAuthMode(mode); setAuthError(''); setAuthSuccess('') }}
    email={email} setEmail={setEmail} password={password} setPassword={setPassword}
    username={username} setUsername={setUsername} displayName={displayName} setDisplayName={setDisplayName}
    busy={authBusy} error={authError} success={authSuccess} onSubmit={handleAuth}
  />

  return <main className={`app-shell ${mobileChatOpen ? 'mobile-chat-open' : ''}`}>
    <aside className="sidebar">
      <div className="sidebar-top">
        <div className="brand-lockup"><span className="brand-mark"><Leaf size={23} strokeWidth={2.3} /></span><span>Chat<span className="brand-accent">Nest</span><small>your little corner of connection</small></span></div>
        <button className="icon-button mobile-refresh" aria-label="Refresh people" onClick={() => void loadPeople()}><Users size={18} /></button>
      </div>
      <div className="section-label"><span>YOUR SPACE</span><span className="online-pill"><i /> CONNECTED</span></div>
      <div className="search-wrap"><Search size={17} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Find someone…" aria-label="Search by name or username" /><kbd>/</kbd></div>
      <div className="people-heading"><span>People</span><span className="count-badge">{filteredPeople.length}</span></div>
      <div className="people-list">
        {peopleLoading ? <div className="list-loading"><LoaderCircle className="spin" size={19} /> Finding your people…</div> :
          filteredPeople.length ? filteredPeople.map(person => <button key={person.id} className={`person-row ${selected?.id === person.id ? 'selected' : ''}`} onClick={() => openPerson(person)}>
            <Avatar profile={person} /><span className="person-copy"><strong>{person.display_name}</strong><small>@{person.username}</small></span><ArrowUpRight className="person-arrow" size={16} />
          </button>) :
          <div className="people-empty"><span className="empty-icon"><Users size={22} /></span><strong>{search ? 'No matches yet' : 'Your circle starts here'}</strong><p>{search ? 'Try another name or username.' : 'When people join ChatNest, you’ll find them here.'}</p></div>
        }
      </div>
      <div className="sidebar-footer">
        <div className="privacy-note"><ShieldCheck size={17} /><span><strong>Your space, kept personal</strong><small>Private conversations, protected by design.</small></span></div>
        <button className="profile-card" onClick={openProfile}>
          <Avatar profile={{ display_name: profile?.display_name || session.user.email || 'You', username: profile?.username || 'you', avatar_url: profile?.avatar_url || null }} />
          <span className="person-copy"><strong>{profile?.display_name || 'Your profile'}</strong><small>@{profile?.username || 'loading'}</small></span><Settings2 size={17} />
        </button>
      </div>
    </aside>

    <section className="chat-panel">
      {!selected ? <div className="welcome-panel">
        <div className="welcome-orbit orbit-one" /><div className="welcome-orbit orbit-two" />
        <motion.div className="welcome-art" initial={{ opacity: 0, y: 12, scale: .96 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: .45 }}>
          <div className="art-leaf"><Leaf size={52} /></div><div className="art-bubble bubble-a"><span /><span /><span /></div><div className="art-bubble bubble-b"><MessageCircle size={21} /></div><Sparkles className="art-sparkle" size={21} />
        </motion.div>
        <div className="welcome-copy"><span className="eyebrow"><Sparkles size={14} /> A LITTLE MORE HUMAN</span><h1>Good conversations<br /><em>grow here.</em></h1><p>Pick someone from your people list and make their day a little brighter.</p></div>
        <div className="welcome-tip"><span><MessageCircleMore size={18} /></span><p><strong>A small hello goes a long way.</strong><br />Your next favourite conversation might be one message away.</p></div>
        <div className="welcome-bottom"><span>MADE FOR REAL CONNECTION</span><span><i /> PRIVATE BY DESIGN</span></div>
      </div> : <div className="conversation">
        <header className="chat-header">
          <button className="icon-button back-button" aria-label="Back to people" onClick={() => setMobileChatOpen(false)}><ArrowLeft size={20} /></button>
          <Avatar profile={selected} size="md" />
          <div className="header-person"><strong>{selected.display_name}</strong><span>@{selected.username}</span></div>
          <button className="header-profile" onClick={() => notify(`Chatting with @${selected.username}`, 'info')} aria-label="Conversation details"><CircleUserRound size={20} /></button>
        </header>
        <div className="message-area">
          {messagesLoading ? <div className="conversation-loading"><span className="typing"><i /><i /><i /></span><p>Opening your conversation…</p></div> :
            messages.length === 0 ? <div className="empty-conversation">
              <div className="empty-chat-art"><div className="empty-chat-circle"><MessageCircleMore size={33} /></div><Sparkles className="empty-spark s1" size={17} /><Sparkles className="empty-spark s2" size={13} /></div>
              <h2>Say hello to {selected.display_name.split(' ')[0]}.</h2><p>This is the start of something good.<br />Send the first message whenever you’re ready.</p>
              <button className="suggestion-chip" onClick={() => { setMessageText('Hey! 👋'); messageInputRef.current?.focus() }}>Hey there! 👋 <ArrowUpRight size={14} /></button>
            </div> : <div className="messages-stack">
              {messages.map((message, index) => {
                const mine = message.sender_id === session.user.id
                const prev = messages[index - 1]
                const showDate = !prev || new Date(prev.created_at).toDateString() !== new Date(message.created_at).toDateString()
                return <div key={message.id}>
                  {showDate && <div className="date-divider"><span>{formatDay(message.created_at)}</span></div>}
                  <motion.div className={`message-line ${mine ? 'mine' : 'theirs'}`} initial={{ opacity: 0, y: 8, scale: .98 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: .2 }}>
                    {!mine && <Avatar profile={selected} size="sm" />}
                    <div className={`message-bubble ${mine ? 'mine-bubble' : 'their-bubble'}`}><p>{message.body}</p><div className="message-meta"><time dateTime={message.created_at}>{formatTime(message.created_at)}</time>{mine && <CheckCheck size={14} />}</div></div>
                  </motion.div>
                </div>
              })}
              <div ref={bottomRef} />
            </div>
          }
        </div>
        <form className="composer" onSubmit={sendMessage}>
          <div className="composer-field"><input ref={messageInputRef} value={messageText} onChange={e => setMessageText(e.target.value)} maxLength={4000} placeholder={`Message ${selected.display_name.split(' ')[0]}…`} aria-label="Write a message" /><span className="char-count">{messageText.length > 3500 ? `${messageText.length}/4000` : ''}</span></div>
          <button className="send-button" type="submit" disabled={!messageText.trim() || sending} aria-label="Send message">{sending ? <LoaderCircle className="spin" size={19} /> : <Send size={19} />}</button>
        </form>
        <div className="composer-foot"><LockKeyhole size={12} /><span>Your conversations are only visible to participants.</span></div>
      </div>}
    </section>

    <AnimatePresence>
      {profileOpen && <motion.div className="modal-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={e => { if (e.target === e.currentTarget) setProfileOpen(false) }}>
        <motion.section className="profile-modal" role="dialog" aria-modal="true" aria-labelledby="profile-title" initial={{ opacity: 0, y: 18, scale: .97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 12, scale: .98 }}>
          <div className="modal-head"><div><span className="eyebrow">YOUR CORNER</span><h2 id="profile-title">Profile & settings</h2></div><button className="icon-button" onClick={() => setProfileOpen(false)} aria-label="Close settings"><X size={19} /></button></div>
          <div className="profile-hero"><Avatar profile={{ display_name: profile?.display_name || 'You', username: profile?.username || 'you', avatar_url: profile?.avatar_url || null }} size="lg" /><div><strong>{profile?.display_name || 'Your profile'}</strong><span>@{profile?.username || 'loading'}</span></div><span className="profile-check"><Check size={15} /></span></div>
          <form className="profile-form" onSubmit={saveProfile}>
            <label>Display name<input value={editName} onChange={e => setEditName(e.target.value)} maxLength={60} required /></label>
            <label>Username<div className="username-input"><span>@</span><input value={editUsername} onChange={e => setEditUsername(e.target.value)} minLength={3} maxLength={24} pattern="[A-Za-z0-9_]{3,24}" required /></div><small>3–24 letters, numbers or underscores. Must be unique.</small></label>
            <label>Email address<div className="readonly-input"><Mail size={16} /><input value={session.user.email || ''} readOnly aria-label="Account email address" /></div></label>
            {profileError && <div className="form-error">{profileError}</div>}
            <button className="primary-button full-button" disabled={profileBusy} type="submit">{profileBusy ? <LoaderCircle className="spin" size={17} /> : <Check size={17} />} Save changes</button>
          </form>
          <div className="modal-divider" />
          <button className="logout-button" onClick={() => void handleLogout()}><LogOut size={17} /> Log out of ChatNest <ArrowUpRight size={15} /></button>
          <p className="modal-footnote"><ShieldCheck size={13} /> Your email is private and is never shown in the people directory.</p>
        </motion.section>
      </motion.div>}
    </AnimatePresence>
    <AnimatePresence>{toast && <motion.div className={`toast toast-${toast.kind}`} role="status" initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}><span className="toast-icon">{toast.kind === 'error' ? <X size={16} /> : toast.kind === 'success' ? <Check size={16} /> : <Sparkles size={16} />}</span>{toast.text}<button onClick={() => setToast(null)} aria-label="Dismiss notification"><X size={14} /></button></motion.div>}</AnimatePresence>
  </main>
}

function AuthScreen(props: {
  mode: AuthMode; setMode: (mode: AuthMode) => void; email: string; setEmail: (v: string) => void
  password: string; setPassword: (v: string) => void; username: string; setUsername: (v: string) => void
  displayName: string; setDisplayName: (v: string) => void; busy: boolean; error: string; success: string
  onSubmit: (event: FormEvent) => void
}) {
  return <main className="auth-page">
    <div className="auth-decoration deco-one" /><div className="auth-decoration deco-two" />
    <section className="auth-card">
      <div className="auth-brand"><span className="brand-mark"><Leaf size={24} /></span><span>Chat<span className="brand-accent">Nest</span></span></div>
      <div className="auth-intro"><span className="eyebrow"><Sparkles size={14} /> YOUR LITTLE CORNER OF CONNECTION</span><h1>{props.mode === 'login' ? <>Good to have<br /><em>you back.</em></> : <>Make room for<br /><em>good people.</em></>}</h1><p>{props.mode === 'login' ? 'Your conversations are waiting right where you left them.' : 'Create your account and start a conversation that matters.'}</p></div>
      <div className="auth-tabs"><button className={props.mode === 'login' ? 'active' : ''} onClick={() => props.setMode('login')} type="button">Log in</button><button className={props.mode === 'signup' ? 'active' : ''} onClick={() => props.setMode('signup')} type="button">Create account</button></div>
      <form className="auth-form" onSubmit={props.onSubmit}>
        {props.mode === 'signup' && <>
          <label>Display name<div className="input-with-icon"><UserRound size={17} /><input value={props.displayName} onChange={e => props.setDisplayName(e.target.value)} placeholder="How people know you" autoComplete="name" maxLength={60} required /></div></label>
          <label>Unique username<div className="input-with-icon"><span className="at-sign">@</span><input value={props.username} onChange={e => props.setUsername(e.target.value.replace(/[^a-zA-Z0-9_]/g, '').slice(0, 24))} placeholder="your_username" autoComplete="username" minLength={3} maxLength={24} required /></div><small>3–24 letters, numbers or underscores.</small></label>
        </>}
        <label>Email address<div className="input-with-icon"><Mail size={17} /><input type="email" value={props.email} onChange={e => props.setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" required /></div></label>
        <label>Password<div className="input-with-icon"><LockKeyhole size={17} /><input type="password" value={props.password} onChange={e => props.setPassword(e.target.value)} placeholder="At least 8 characters" autoComplete={props.mode === 'login' ? 'current-password' : 'new-password'} minLength={8} required /></div></label>
        {props.error && <div className="form-error" role="alert">{props.error}</div>}
        {props.success && <div className="form-success" role="status">{props.success}</div>}
        <button className="primary-button auth-submit" type="submit" disabled={props.busy}>{props.busy ? <LoaderCircle className="spin" size={18} /> : props.mode === 'login' ? <ArrowUpRight size={18} /> : <Sparkles size={18} />}{props.busy ? 'One moment…' : props.mode === 'login' ? 'Welcome back' : 'Create my account'}</button>
      </form>
      <div className="auth-trust"><ShieldCheck size={15} /><span>Private by design. Built for real conversations.</span></div>
    </section>
    <aside className="auth-side">
      <div className="auth-side-art"><div className="side-orb orb-large" /><div className="side-orb orb-small" /><div className="side-message msg-one"><span className="mini-avatar av1">M</span><span><strong>Maya</strong><small>That made my day 🌱</small></span><span className="tiny-time">now</span></div><div className="side-message msg-two"><span className="mini-avatar av2">J</span><span><strong>Jamie</strong><small>Tell me everything!</small></span><span className="tiny-time">2m</span></div><div className="side-center-icon"><MessageCircleMore size={42} /></div><Sparkles className="side-sparkle spark-a" size={23} /><Sparkles className="side-sparkle spark-b" size={16} /></div>
      <div className="auth-side-copy"><span className="eyebrow">LESS NOISE. MORE MEANING.</span><h2>Small messages.<br /><em>Real connection.</em></h2><p>A softer space to keep in touch with the people who make life feel a little more like life.</p><div className="side-points"><span><Check size={15} /> Simple and thoughtful</span><span><Check size={15} /> Your own private corner</span><span><Check size={15} /> Here when you need it</span></div></div>
      <div className="auth-side-footer">CHATNEST <span>·</span> A CALMER WAY TO CONNECT</div>
    </aside>
  </main>
}

function SetupScreen() {
  return <main className="setup-page"><div className="setup-card"><div className="auth-brand"><span className="brand-mark"><Leaf size={24} /></span><span>Chat<span className="brand-accent">Nest</span></span></div><span className="setup-icon"><Settings2 size={27} /></span><h1>One little setup<br /><em>before we nest.</em></h1><p>Connect ChatNest to your Supabase project to enable secure accounts and real-time messages. No fake data, no pretend conversations.</p><ol><li><span>01</span><div><strong>Create a Supabase project</strong><small>Start a free project at supabase.com.</small></div></li><li><span>02</span><div><strong>Run the database schema</strong><small>Paste <code>supabase/schema.sql</code> into the SQL Editor and run it.</small></div></li><li><span>03</span><div><strong>Add your environment variables</strong><small>Copy <code>.env.example</code> to <code>.env</code> and fill in your project URL and anon/publishable key.</small></div></li></ol><div className="setup-note"><ShieldCheck size={17} /><span>Only the public anon/publishable key belongs in frontend env vars. Never use a service-role key here.</span></div><p className="setup-restart">Then restart the development server.</p></div></main>
}

export default App

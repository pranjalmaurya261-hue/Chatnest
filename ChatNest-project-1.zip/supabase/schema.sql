-- ChatNest schema. Run the entire script in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null,
  display_name text not null default 'New member',
  avatar_url text,
  created_at timestamptz not null default now(),
  constraint username_format check (username ~ '^[a-zA-Z0-9_]{3,24}$'),
  constraint display_name_length check (char_length(trim(display_name)) between 1 and 60)
);

-- Usernames are unique regardless of capitalization.
create unique index if not exists profiles_username_lower_unique on public.profiles (lower(username));
create index if not exists profiles_display_name_search on public.profiles using gin (to_tsvector('simple', display_name));

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now(),
  constraint message_body_length check (char_length(trim(body)) between 1 and 4000),
  constraint cannot_message_self check (sender_id <> receiver_id)
);

create index if not exists messages_conversation_time_idx
  on public.messages (sender_id, receiver_id, created_at desc);
create index if not exists messages_receiver_time_idx
  on public.messages (receiver_id, sender_id, created_at desc);

alter table public.profiles enable row level security;
alter table public.messages enable row level security;

-- Profiles are discoverable to signed-in users, but email is never stored in this table.
drop policy if exists "Signed-in users can view profiles" on public.profiles;
create policy "Signed-in users can view profiles"
  on public.profiles for select to authenticated using (true);

drop policy if exists "Users can create their own profile" on public.profiles;
create policy "Users can create their own profile"
  on public.profiles for insert to authenticated with check (auth.uid() = id);

drop policy if exists "Users can update their own profile" on public.profiles;
create policy "Users can update their own profile"
  on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "Participants can read their messages" on public.messages;
create policy "Participants can read their messages"
  on public.messages for select to authenticated
  using (auth.uid() = sender_id or auth.uid() = receiver_id);

drop policy if exists "Users can send messages as themselves" on public.messages;
create policy "Users can send messages as themselves"
  on public.messages for insert to authenticated
  with check (
    auth.uid() = sender_id
    and sender_id <> receiver_id
    and char_length(trim(body)) between 1 and 4000
    and exists (select 1 from public.profiles p where p.id = receiver_id)
  );

-- Messages are immutable from the client: no UPDATE or DELETE policies are granted.
revoke all on public.profiles from anon;
revoke all on public.messages from anon;
grant select, insert, update on public.profiles to authenticated;
grant select, insert on public.messages to authenticated;

-- Create a profile automatically at signup. A unique suffix prevents collisions
-- if the requested username is already taken; the UI still validates usernames.
create or replace function public.handle_new_chatnest_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  requested_username text;
  safe_username text;
  base_name text;
begin
  requested_username := coalesce(new.raw_user_meta_data ->> 'username', '');
  base_name := coalesce(nullif(new.raw_user_meta_data ->> 'display_name', ''), 'New member');

  if requested_username !~ '^[a-zA-Z0-9_]{3,24}$' then
    requested_username := 'user_' || substr(replace(new.id::text, '-', ''), 1, 10);
  end if;

  safe_username := requested_username;
  if exists (select 1 from public.profiles p where lower(p.username) = lower(safe_username)) then
    safe_username := left(requested_username, 13) || '_' || substr(replace(new.id::text, '-', ''), 1, 8);
  end if;

  insert into public.profiles (id, username, display_name)
  values (new.id, safe_username, left(base_name, 60))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_chatnest on auth.users;
create trigger on_auth_user_created_chatnest
  after insert on auth.users
  for each row execute procedure public.handle_new_chatnest_user();

-- Realtime is used for actual Postgres changes, not simulated client messages.
do $$
begin
  alter publication supabase_realtime add table public.messages;
exception
  when duplicate_object then null;
  when undefined_object then null;
end $$;
